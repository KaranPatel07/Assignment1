
package assignment1;

public class employee {
    
    int age;
    String name,city;
    void fun(){
        System.out.println("The name is:"+name);
        System.out.println("The age is :"+age);
        System.out.println("The city is :"+city);
    }
    public static void main(String[] args) {
            
        employee e1=new employee();
        e1.age=23;
        employee e2=new employee();
        e1.city="Chennai";
        e1.name="Saurab";
        e1.fun();
    }
    
}
